#!/bin/sh

scriptName="bbc_pmt_v6.py -t short -d /dev/dvb/adapter0/demux0"
logName=/dev/null
#logName=/tmp/bbc_pmt.log

while [ 1 ]
do
	echo "=== starting $scriptName" >> $logName
	$scriptPath/$scriptName >> $logName 2>&1
	echo "=== $scriptName exited..." >> $logName
done

