# -*- coding: utf-8 -*-
#
# This plugin is open source but it is NOT free software.
#
# This plugin may only be distributed to and executed on hardware which
# is licensed by Dream Property GmbH.
# In other words:
# It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
# to hardware which is NOT licensed by Dream Property GmbH.
# It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
# on hardware which is NOT licensed by Dream Property GmbH.
#
# It's not allowed to publish any modified version of this plugin without the author's consent.


from Components.ActionMap import ActionMap
from Components.Button import Button
from Components.ConfigList import ConfigListScreen
from Components.Label import Label
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaBlend
from Components.Pixmap import Pixmap
from Components.ScrollLabel import ScrollLabel
from Components.Sources.List import List
from Components.config import config, ConfigInteger, ConfigSubsection, ConfigYesNo, ConfigText, ConfigClock, getConfigListEntry, ConfigSelection
from Plugins.Plugin import PluginDescriptor
from Screens.ChoiceBox import ChoiceBox
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Tools.Directories import fileExists, resolveFilename, SCOPE_CURRENT_SKIN
from Tools.LoadPixmap import LoadPixmap

from enigma import eDVBLocalTimeHandler, gFont, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, RT_VALIGN_CENTER, RT_WRAP, eServiceReference, eServiceCenter, eDVBDB
from time import time, strftime, localtime, mktime
from twisted.internet import defer
from twisted.web.client import downloadPage, _makeGetterFactory, HTTPClientFactory
from twisted.internet.ssl import ClientContextFactory
from twisted.internet._sslverify import ClientTLSOptions
import xml.etree.cElementTree as Tree

from plutotimer import plutoepgupdate
from plutoepgloader import PlutoEPGLoader
from OpenSSL import SSL
import uuid
import json
import re

# for localized messages
from . import _

now = localtime()
begin = mktime((
	now.tm_year, now.tm_mon, now.tm_mday, 19, 0, \
	0, now.tm_wday, now.tm_yday, now.tm_isdst)
)

config.plugins.pluto = ConfigSubsection()
config.plugins.pluto.lastupdate = ConfigInteger(0)
config.plugins.pluto.enabled = ConfigYesNo(default = True)
config.plugins.pluto.uuid = ConfigText(default = str(uuid.uuid4()), fixed_size = False)
config.plugins.pluto.updatetime = ConfigClock(default = int(begin))
config.plugins.pluto.updateinterval = ConfigSelection(default="12", choices= [("1", "1"),("2", "2"),("3", "3"),("4", "4"),("5", "5"),("6", "6"),("7", "7"),("8", "8"),("9", "9"),("10", "10"),("11", "11"),("12", "12"),("13", "13"),("14", "14"),("15", "15"), ("16", "16"),("17", "17"),("18", "18"),("19", "19"),("20", "20"),("21", "21"),("22", "22"),("23", "23"), ("24", "24")])

def timeCallback():
	time_updated_conn = None
	"""Time Callback/Autostart management."""
	thInstance = eDVBLocalTimeHandler.getInstance()
	if not thInstance.ready():
		time_updated_conn = thInstance.m_timeUpdated.connect(timeReadyOrUpdated)
	else:
		timeReadyOrUpdated()
		
def timeReadyOrUpdated():
	print "[pluto] - Time is ready or updated"
	plutoepgupdate.setPlutoEPGTimer()

def sessionstart(reason, **kwargs):
	if reason == 0 and "session" in kwargs:
		session = kwargs["session"]
		print "[PlutoEPG] - last update: ", config.plugins.pluto.lastupdate.value
		print "[PlutoEPG] - update enabled: ", config.plugins.pluto.enabled.value
		print "local", localtime(config.plugins.pluto.lastupdate.value)
		
		if config.plugins.pluto.enabled.value:
		
			delta = int(time()) - config.plugins.pluto.lastupdate.value
			
			# last update was more than the configured interval in the past (deduct a two min safety net)
			if delta >= (int(config.plugins.pluto.updateinterval.value)*3600)-120:
				timeCallback()
				plutoepgupdate.setSession(session)
			elif (strftime("%j", localtime(int(time()))) > strftime("%j", localtime(config.plugins.pluto.lastupdate.value))) or (strftime("%j", localtime(int(time()))) == "1" and strftime("%j", localtime(int(time()))) != "1"):
				timeCallback()
				plutoepgupdate.setSession(session)
			else:
				print "[plutoEPG] - last update was less than %s hours ago - no update required" %(config.plugins.pluto.updateinterval.value)

def main(session, ref=None, csel=None, **kwargs):
	session.open(PlutoEPG)

def plutotv(session, **kwargs):
	session.open(PlutoTV)

def Plugins(**kwargs):
	list = [
		PluginDescriptor(name="PlutoTV", description="PlutoTV",
		where = [PluginDescriptor.WHERE_PLUGINMENU ], fnc=plutotv, icon="plutotv.svg"),
		PluginDescriptor(name=_("Update EPG for PlutoTV"), description=_("Update EPG for PlutoTV"),  
		where = [PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU ], fnc=main, helperfnc=checkForBouquet),
		PluginDescriptor(where=[PluginDescriptor.WHERE_SESSIONSTART], fnc=sessionstart)
		]
	return list

def checkForBouquet(csel):
	if csel.movemode:
		return (False, False)
	inBouquet = csel.getMutableList() is not None
	current_root = csel.getRoot()
	current_root_path = current_root and current_root.getPath()
	inPlutoBouquet = current_root_path and current_root_path.find('FROM BOUQUET "userbouquet.pluto') != -1
	return inBouquet and inPlutoBouquet

class PlutoConfig(Screen, ConfigListScreen):
	skin = """
		<screen name="PlutoConfig" size="1000,900" position="center,100" title="PlutoTV" >
			<widget name="config" position="10,10" size="980,800" scrollbarMode="showOnDemand" />
			<ePixmap alphatest="blend" pixmap="skin_default/buttons/red.png" position="10,820" zPosition="3" size="30,30" transparent="1" name="red" />
			<widget name="ButtonRedText" position="50,820" size="350,30" valign="center" halign="left" font="Regular;25" transparent="1" />
			<ePixmap alphatest="blend" pixmap="skin_default/buttons/green.png" position="460,820" zPosition="3" size="30,30" transparent="1" name="green" />
			<widget name="ButtonGreenText" position="500,820" size="350,30" valign="center" halign="left" font="Regular;25" transparent="1" />
		</screen>
		"""	
	def __init__(self, session):
		Screen.__init__(self, session)
		
		self.list = []
		ConfigListScreen.__init__(self, self.list, session = session)
		self.createSetup()
		
		self["actions"] = ActionMap(["OkCancelActions", "ColorActions"],
		{
			"ok":		self.save,
			"cancel":	self.cancel,
			"green":		self.save,
			"red": 	self.cancel,
		}, -2)

		self["red"] = Pixmap()
		self["ButtonRedText"] = Label(_("Cancel"))		
		self["green"] = Pixmap()
		self["ButtonGreenText"] = Label(_("Save"))
	
	def createSetup(self):
		self.list = []
		self.updateEnabled = getConfigListEntry(_("Enable automatic EPG update"), config.plugins.pluto.enabled)
		self.list.append(self.updateEnabled)
		if config.plugins.pluto.enabled.value:
			self.list.append(getConfigListEntry(_("Update EPG at"), config.plugins.pluto.updatetime))
			self.list.append(getConfigListEntry(_("Update every n hours"), config.plugins.pluto.updateinterval))
			
		self["config"].setList(self.list)

	def keyRight(self):
		ConfigListScreen.keyRight(self)
		if self["config"].getCurrent()[1] in (self.updateEnabled):
			self.createSetup()

	def keyLeft(self):
		ConfigListScreen.keyLeft(self)
		if self["config"].getCurrent()[1] in (self.updateEnabled):
			self.createSetup()
		
	def save(self):
		ConfigListScreen.saveAll(self)
		self.close(True)
		
	def cancel(self):
		ConfigListScreen.keyCancel(self)
		
class PlutoEPG(Screen, PlutoEPGLoader):
	skin = """
		<screen position="center,center" size="500,300" title="Pluto EPG" >
			<widget name="infoText" position="10,10" size="480,280" valign="top" halign="left" zPosition="10" font="Regular;25" transparent="1" />			
		</screen>
		"""
		
	def __init__(self, session):
		Screen.__init__(self, session)
		
		PlutoEPGLoader.__init__(self, session, True)
		
		self.session = session

		self["infoText"] = ScrollLabel()
		
		self["OkCancelActions"] = ActionMap(["OkCancelActions"],
		{
			"ok":		self.close,
			"cancel":	self.close,
		}, -1)

		self["DirectionActions"] = ActionMap(["DirectionActions"],
		{
			"up": self["infoText"].pageUp,
			"down": self["infoText"].pageDown,
			"left": self["infoText"].pageUp,
			"right": self["infoText"].pageDown,
		}, -1)
		
		self.startUpdate()
		
class PlutoTV(Screen, PlutoEPGLoader):
	skin = """
		<screen position="center,65" size="1900,1000" title="PlutoTV" >
			<widget source="channelList" render="Listbox" position="0,50" size="1900,900">
				<convert type="TemplatedMultiContent">
					{
						"templates":
							{
								"default":
									(
										100,
											[
												MultiContentEntryPixmapAlphaBlend(pos=(10,25), size=(180,50), png=5, scale_flags=SCALE_STRETCH),
												MultiContentEntryText(pos=(200,0), size=(250,100), flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER|RT_WRAP, font=1, text=0),
												MultiContentEntryText(pos=(450,0), size=(1100,100), flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER|RT_WRAP, font=1, text=2),
												MultiContentEntryText(pos=(1550,0), size=(250,100), flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER|RT_WRAP, font=1, text=4),
												MultiContentEntryPixmapAlphaTest(pos=(1800,38), size=(24, 24), png = 11, scale_flags=SCALE_HEIGHT)
											]
									),
							},
						"fonts": 
							[
								gFont("Regular", 28), gFont("Regular", 24),
							]
					}
				</convert>
			</widget>
			<ePixmap alphatest="blend" pixmap="skin_default/buttons/red.png" position="10,950" zPosition="3" size="30,30" transparent="1" name="red" />
			<widget name="ButtonRedText" position="50,950" size="275,30" valign="center" halign="left" font="Regular;25" transparent="1" />
			<ePixmap alphatest="blend" pixmap="skin_default/buttons/green.png" position="340,950" zPosition="3" size="30,30" transparent="1" name="green" />
			<widget name="ButtonGreenText" position="380,950" size="275,30" valign="center" halign="left" font="Regular;25" transparent="1" />
			<ePixmap alphatest="blend" pixmap="skin_default/buttons/yellow.png" position="670,950" zPosition="3" size="30,30" transparent="1" name="yellow" />
			<widget name="ButtonYellowText" position="710,950" size="275,30" valign="center" halign="left" font="Regular;25" transparent="1" />
			<ePixmap alphatest="blend" pixmap="skin_default/buttons/blue.png" position="1000,950" zPosition="3" size="30,30" transparent="1" name="blue" />
			<widget name="ButtonBlueText" position="1040,950" size="275,30" valign="center" halign="left" font="Regular;25" transparent="1" />
			<eLabel font="Regular;20" position="1320,950" size="60,30" text="OK" transparent="0" valign="center" halign="center" foregroundColor="#ffffff" backgroundColor="#787878" zPosition="6"/>
			<widget name="oktext" position="1395,950" size="150,30" valign="center" halign="left" font="Regular;25" transparent="1" />
			<eLabel font="Regular;20" position="1560,950" size="60,30" text="MENU" transparent="0" valign="center" halign="center" foregroundColor="#ffffff" backgroundColor="#787878" zPosition="6"/>
			<widget name="menutext" position="1635,950" size="275,30" valign="center" halign="left" font="Regular;25" transparent="1" />
		</screen>
		"""

	def __init__(self, session):
		Screen.__init__(self, session)
		
		self.session = session
		self.selectedChannels = []
		self.currentChannels = []
		self.channelDataList = []
		self.enablePicons = False
		self.isMerlin = False
		self.serviceHandler = eServiceCenter.getInstance()
		
		self.iconOn = LoadPixmap(resolveFilename(SCOPE_CURRENT_SKIN, "skin_default/icons/lock_on.png"))
		self.iconOff = LoadPixmap(resolveFilename(SCOPE_CURRENT_SKIN, "skin_default/icons/lock_off.png"))

		self["channelList"] = List()
		self["channelList"].setBuildFunc(self.buildChannelEntry)
		self["channelList"].onSelectionChanged.append(self.setLabelText)
		
		self["ButtonRedText"] = Button(_("Update EPG"))
		self["red"] = Pixmap()
		
		self["ButtonGreenText"] = Button(_("Update Pluto Bouquet"))
		self["green"] = Pixmap()
		
		self["ButtonYellowText"] = Button(_("Get Picon"))
		self["ButtonYellowText"].hide()
		self["yellow"] = Pixmap()

		self["ButtonBlueText"] = Button(_("Sort by..."))
		self["blue"] = Pixmap()
		
		self["oktext"] = Label()
		self["menutext"] = Label(_("Settings"))
		
		self["OkCancelActions"] = ActionMap(["OkCancelActions"],
		{
			"ok":		self.changeSelectState,
			"cancel":	self.close,
		}, -1)
		
		self["MenuActions"] = ActionMap(["MenuActions"],
		{
			"menu":		self.openConfig,
		}, -1)
		
		self["ColorActions"] = ActionMap(["ColorActions"],
		{
			"red":		self.updateEPG,
			"green":	self.generateBouquet,
			"yellow":	self.downloadPicons,
			"blue":		self.openSortSelector,
		}, -1)

		self.setYellowButton()		
		self.getChannels()

	def openSortSelector(self):
		self.session.openWithCallback(self.sortList, ChoiceBox, title = _("Sort by..."), list = [(_("Service name"), 0), (_("Service number"), 1), (_("Category"), 4) ])
		
	def sortList(self, retval):
		if retval is not None:
			print "sorting channels by %s" %(retval[0])
			self.channelDataList.sort(key = lambda x: x[retval[1]])
			self["channelList"].setList(self.channelDataList)
	
	def setYellowButton(self):
		if fileExists("/usr/lib/enigma2/python/Plugins/newnigma2/"):
			self.piconPath = "/picons/piconHD"
			self["ButtonYellowText"].show()
			self.enablePicons = True
		elif fileExists("/usr/lib/enigma2/python/Components/Merlin.py"):
			self.piconPath = "/data/picon_220x132"
			self["ButtonYellowText"].show()
			self.enablePicons = True
			self.isMerlin = True
		
	
	def openConfig(self):
		self.session.open(PlutoConfig)

	def setLabelText(self):
		cur = self["channelList"].getCurrent()
		if cur is not None:
			id = cur[8]
			if id in self.selectedChannels:
				self["oktext"].setText(_("Deselect"))
			else:
				self["oktext"].setText(_("Select"))

	def updateEPG(self):
		self.session.open(PlutoEPG)

	def downloadPicons(self):
		if self.enablePicons:
			if len(self.selectedChannels)>0:
				ds = []
				self.successCounter = 0
				self.errorCounter = 0
			
				for entry in self.channelDataList:
					if entry[8] in self.selectedChannels:
						pos = entry[10].find("https")
						if pos != -1:
							if self.isMerlin and config.merlin2.skin_piconmode.value == "Name":
								ref = eServiceReference(entry[10])
								info = self.serviceHandler .info(ref)
								sref = info and info.getName(ref)
								if sref is not None:
									sref = sref.replace('\xc2\x86', '').replace('\xc2\x87', '')	
									sref = re.sub('[^0-9a-zA-Z]+', '_', sref)
							else:
								x = entry[10].split(':')
								x[1]='0' #replace flags field
								del x[x[10] and 11 or 10:]
								sref = '1_'+'_'.join(x[1:10])
				
							if not fileExists("%s/%s.png" %(self.piconPath, sref)):
								d = downloadPage("https://images.pluto.tv/channels/%s/logo.png?fit=fill&fm=png&h=132&w=220" %(entry[8]), "%s/%s.png" %(self.piconPath, sref))
								d.addCallback(self.increaseCounter, "OK")
								d.addErrback(self.increaseCounter, "NOK")
								ds.append(d)
							
				if len(ds) > 0:
					dlist = defer.DeferredList(ds, consumeErrors=True)
					dlist.addCallback(self.showDownloadSummary)
					dlist.addErrback(self.showDownloadSummary)
			else:
				self.session.open(MessageBox, text=_("No channel selected"),windowTitle="PlutoTV", type=MessageBox.TYPE_INFO, timeout=4)
		
	def increaseCounter(self, result, state):
		if state == "OK":
			self.successCounter += 1
		elif state == "NOK":
			self.errorCounter += 1
			
		return
		
	def showDownloadSummary(self, result):
		self.session.open(MessageBox, text=_("Download finished.\nSuccessful: %d\nFailed: %d" %(self.successCounter, self.errorCounter)), windowTitle="PlutoTV", type=MessageBox.TYPE_INFO, timeout=4)

	def changeSelectState(self):
		cur = self["channelList"].getCurrent()
		
		if cur is not None:
			id = cur[8]
			if id in self.selectedChannels:
				self.selectedChannels.remove(id)
			else:
				self.selectedChannels.append(id)
		
			self["channelList"].updateList(self.channelDataList)	
			self.setLabelText()		

	def generateBouquet(self):
		summaryText = ""
		if len(self.selectedChannels)>0 or len(self.currentChannels)>0:
			mutableBouquetList = self.serviceHandler.list(eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "bouquets.tv" ORDER BY bouquet')).startEdit()
			
			tree = Tree.parse("/etc/enigma2/channels_pluto.xml")
			xmlroot = tree.getroot()
		
			if mutableBouquetList:
				bName = "Pluto (TV)"
		
				bref = '1:7:1:0:0:0:0:0:0:0:FROM BOUQUET \"userbouquet.pluto__tv_.tv\" ORDER BY bouquet'
				new_bouquet_ref = eServiceReference(bref)
			
				if not mutableBouquetList.addService(new_bouquet_ref):
					mutableBouquetList.flushChanges()
					eDVBDB.getInstance().reloadBouquets()
					setbName = True
					summaryText += _("Bouquet Pluto created")
				else:
					setbName = False
					print "bouquet pluto already exists"

				# get the bouquet
				mutableBouquet = self.serviceHandler.list(new_bouquet_ref).startEdit()
			
				if mutableBouquet:
					if setbName:
						mutableBouquet.setListName(bName)
					for entry in self.channelDataList:
						if entry[8] in self.selectedChannels and not entry[8] in self.currentChannels:
							ref = eServiceReference(entry[10])
							ref.setName(entry[0])
							
							if not mutableBouquet.addService(ref):
								mutableBouquet.flushChanges()
								self.currentChannels.append(entry[8])
								srefgroups = re.search('(.*?)https', entry[10])
								srefstring = ""
								if srefgroups is not None:
									srefstring = srefgroups.group(1)
									if xmlroot.tag == "channels":
										newchannel = Tree.SubElement(xmlroot, "channel", {"blacklisted":"0", "sref": srefstring})
										newchannel.text = entry[0]
								summaryText += "\n"
								summaryText += _("Channel %s added" %(entry[0]))
							else:
								print "add service", ref.toString(), "to pluto bouquet failed!"
								summaryText += "\n"
								summaryText += _("Channel %s could not be added" %(entry[0]))
						elif not entry[8] in self.selectedChannels and entry[8] in self.currentChannels:
							ref = eServiceReference(entry[10])
						
							if not mutableBouquet.removeService(ref):
								mutableBouquet.flushChanges()
								self.currentChannels.remove(entry[8])
								srefgroups = re.search('(.*?)https', entry[10])
								srefstring = ""
								if srefgroups is not None:
									srefstring = srefgroups.group(1)								
									remchannel = xmlroot.find("channel[@sref='%s']" %(srefstring))
									if remchannel is not None:
										xmlroot.remove(remchannel)
								summaryText += "\n"
								summaryText += _("Channel %s removed" %(entry[0]))
							else:
								summaryText += "\n"
								summaryText += _("Channel %s could not be removed" %(entry[0]))
								
								print "remove service", ref.toString(), "from pluto bouquet failed!"							
			
			tree.write("/etc/enigma2/channels_pluto.xml")
		else:
			summaryText += _("No channels selected nor deselected")
		
		if summaryText != "":
			self.session.open(MessageBox, summaryText, MessageBox.TYPE_INFO, timeout=5, windowTitle="PlutoTV")
					
	def buildChannelEntry(self, channelName, channelNumber, channelSummary, channelVisibility, channelCategory, channelLogo, channelStitched, channelUrl, channelId, channelSlug, channelSref):
		
		logoPic = None
		if fileExists("/usr/lib/enigma2/python/Plugins/Extensions/pluto/logo/%s.png" %(channelId)):
			logoPic = LoadPixmap("/usr/lib/enigma2/python/Plugins/Extensions/pluto/logo/%s.png" %(channelId))
		else:
			downloadPage("https://images.pluto.tv/channels/%s/logo.png?fit=fill&fm=png&h=50&w=175" %(channelId), "/usr/lib/enigma2/python/Plugins/Extensions/pluto/logo/%s.png" %(channelId)).addCallback(self.updateListWithLogo, channelId).addErrback(self.getError)
			
		if channelVisibility:
			channelVisibilityString = _("Yes")
		else:
			channelVisibilityString = _("No")
			
		iconPic = self.iconOff
		if channelId in self.selectedChannels:
			iconPic = self.iconOn
		
		return [ channelName, channelNumber, channelSummary, channelVisibilityString, channelCategory, logoPic, channelStitched, channelUrl, channelId, channelSlug, channelSref, iconPic ]

	def updateListWithLogo(self, result, channelId):
		self["channelList"].updateList(self.channelDataList)
						
	def getChannels(self):
		# let's first get the services that are already in the bouquet
		bName = "Pluto (TV)"
		
		bref = '1:7:1:0:0:0:0:0:0:0:FROM BOUQUET \"userbouquet.pluto__tv_.tv\" ORDER BY bouquet'
		
		slist = self.serviceHandler.list(eServiceReference(bref))
		if slist is not None:
			while True:
				service = slist.getNext()
				if not service.valid():
					break
					
				result = re.search('channel\/(.*?)\/', service.toString() )
				if result is not None:
					self.currentChannels.append(result.group(1))
					self.selectedChannels.append(result.group(1))	
	
		url = "https://api.pluto.tv/v2/channels.json?%s" %(config.plugins.pluto.uuid.value)
		
		headers = {
			'User-agent': 'Mozilla/5.0 (Windows NT 6.2; rv:24.0) Gecko/20100101 Firefox/24.0'
		}
		
		d = myGetPage(url, headers=headers).addCallback(self.processChannelData).addErrback(self.getError)
		
	def processChannelData(self, result):
		self.channelDataList = []

		channelList = json.loads(result)

		for channel in channelList:
			channelName = channel.get('name').encode('utf-8','ignore')
			channelNumber = channel.get('number')
			channelSummary = channel.get('summary').encode('utf-8','ignore')
			channelVisibility = channel.get('visibility').encode('utf-8','ignore')
			channelCategory = channel.get('category').encode('utf-8','ignore')
			if channelCategory == "Samsung":
				continue
			channelLogoDict = channel.get('colorLogoSVG', {})
			channelLogo = channelLogoDict.get('path').encode('utf-8','ignore')
			channelStitched = channel.get('isStitched')
			channelUrlDict = channel.get('stitched', {})
			channelUrlList = channelUrlDict.get('urls', [])
			for channelUrlOption in channelUrlList:
				streamType = channelUrlOption.get('type').encode('utf-8','ignore')
				if streamType == 'hls':
					channelUrl = channelUrlOption.get('url').encode('utf-8','ignore')
					if channelUrl is not None:
						channelUrl.replace('\u0026', '&')
						break
			channelId = channel.get('_id').encode('utf-8','ignore')
			channelSlug = channel.get('slug').encode('utf-8','ignore')
			srefurl = "https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/%s/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&appName=rokuchannel" %(channelId)
			
			srefurl = srefurl.replace(':', '%3a')
			channelSref = "4097:256:19:%d:6:1F8:0:0:0:0:%s:%s" %(channelNumber, srefurl, channelName)

			
			self.channelDataList.append((channelName, channelNumber, channelSummary, channelVisibility, channelCategory, channelLogo, channelStitched, channelUrl, channelId, channelSlug, channelSref ))
		
		self.channelDataList.sort(key = lambda x: x[4])
		self["channelList"].setList(self.channelDataList)
		self.setLabelText()
		
	def getError(self, error):
		print "error", error.getErrorMessage()
		

class MyContextFactory(ClientContextFactory):
	def __init__(self):
		self.method = SSL.SSLv23_METHOD
		
	def getContext(self, hostname="pluto.tv"):
		ctx = ClientContextFactory.getContext(self)
		ctx.set_options(SSL.OP_ALL)
		if hostname is not None:
			ClientTLSOptions(hostname, ctx)
		
		return ctx

def myGetPage(url, contextFactory=MyContextFactory(), *args, **kwargs):
	if contextFactory is None:
		contextFactory = contextFactory
	return _makeGetterFactory(
		url,
		HTTPClientFactory,
		contextFactory=contextFactory,
		*args, **kwargs).deferred			