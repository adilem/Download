#!/bin/sh
#### "*******************************************"
#### "              Created By RAED              *"
#### "*        << Edited by  MOHAMED_OS >>       *"
#### "*        ..:: www.tunisia-sat.com ::..     *"
#### "*******************************************"
# Type: Oscam

/usr/script/ncam_cs.sh stop
sleep 5

rm -rf /usr/bin/ncam
rm -rf /usr/script/ncam_cs.sh
rm -rf /usr/uninstall/ncam_remove.sh
rm -rf /lib/systemd/system/ncam.service
rm -rf /lib/systemd/system/ncam.socket

exit 0
