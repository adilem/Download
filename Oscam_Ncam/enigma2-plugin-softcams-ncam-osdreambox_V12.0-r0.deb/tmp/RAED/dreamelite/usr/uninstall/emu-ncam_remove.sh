#!/bin/sh
dpkg -r enigma2-plugin-softcams-ncam-armhf-images
exit 0
