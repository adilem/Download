#!/usr/bin/python -u
import socket
import time
import os
import re
import glob
import sys
import getopt
import xml.etree.ElementTree as ET

# cmdline
try:
	opts, args = getopt.getopt(sys.argv[1:],"ht:d:a:p:cs:")
except getopt.GetoptError:
	print 'needed params: -t <short|long> -d <demux>'
	print 'optional params: -a <user:password> -p <port> -c -s <timeout>'
	sys.exit(2)
auth = ""
port = ""
clearPmtCheck = False
timeout = 200
for opt, arg in opts:
	if opt == '-h':
		print 'needed params: -t <short|long> -d <demux>'
		print 'optional params: -a <user:password> -p <port> -c -s <timeout>'
		lsDemux = glob.glob("/dev/dvb/adapter*/demux*")
		print "available demuxes:"
		for file in lsDemux:
        		print file
        	if len(lsDemux) == 0:
                	print "No demux available"
		sys.exit()
	elif opt in ("-t"):
		capmtType = arg
	elif opt in ("-d"):
		demux = arg
	elif opt in ("-a"):
		auth = arg + "@"
	elif opt in ("-p"):
		port = ":" + arg
	elif opt in ("-c"):
		clearPmtCheck = True
	elif opt in ("-s"):
		timeout = int(arg, 10)
print "capmtType: %s, demux: %s" % (capmtType, demux)

# init
#capmt = bytearray("\x9f\x80\x32\x1e\x03\x44\x40\x09\x00\x13\x01\x81\x08\x0C\xFD\xAC\xE7\x10\x00\x00\x01\x82\x02\x08\x03\x84\x02\x17\xD4\x0d\x17\xD4\x00\x00")
oldSid = "0x" # no SID
namespace = ":CFDACE7:"
socketIsOpen = False

# main loop
while True:
	time.sleep(0.5)
	pipe = os.popen("""wget -q -O - http://%slocalhost%s/web/subservices | grep %s | awk -F ":" '{print $4}'""" % (auth,port,namespace))
	currentSid = "0x" + pipe.readline().rstrip().lower()
	if currentSid == oldSid:
		continue

	# we have some zap
	print "currentSid: %s" % currentSid
	oldSid = currentSid
	if socketIsOpen:
		s.shutdown(socket.SHUT_RDWR)
		s.close()
		socketIsOpen = False
	if currentSid == "0x":
		continue

	# check SID
	print "trying with demux %s" % demux
	pipe = os.popen("dvbsnoop -timeout %d -nph -pd 3 -n 1 -demux %s 0x0 | grep -A 1 %s | grep Program_map_PID" % (timeout,demux,currentSid))
	m = re.search(r"\((\w+)\)", pipe.readline())
	if not m:
		oldSid = "0x" # try to get PAT again in next iteration of main loop
		continue
	pmtPid = m.group(1)
	print "pmtPid: %s" % pmtPid

	# is PMT being broadcasted?
	if clearPmtCheck:
		pipe = os.popen("""dvbsnoop -timeout %d -pd 1 -n 1 -demux %s %s | grep "received" | wc -l""" % (timeout,demux,pmtPid))
		if pipe.readline().rstrip() == "1":
			continue

	# extract demux number
	m = re.search("\d+$", demux)
	demuxNb = m.group()

	# PMT missing, build CAPMT
        currentSidI = int(currentSid, 16)
	demuxNbI = int(demuxNb)
        pmtPidI = int(pmtPid, 16)

	capmt = bytearray("\x9f\x80\x32\x00\x03") # capmt start
	capmt.extend([(currentSidI >> 8) & 0xff, currentSidI & 0xff]) # SID
	capmt.extend("\x09\x00\x13\x01\x81\x08\x0C\xFD\xAC\xE7\x10\x00\x00\x01") # program info length, reference
	capmt.extend([0x82, 0x02, 1 << demuxNbI, demuxNbI & 0xff]) # camask, demux
	capmt.extend([0x84, 0x02, (pmtPidI >> 8) & 0xff, pmtPidI & 0xff]) # PMT PID

	if capmtType == "long":
		# descramble VPID and APID
		pipe = os.popen("""wget -q -O - http://%slocalhost%s/web/getcurrent""" % (auth,port))
		tree = ET.parse(pipe)
		root = tree.getroot()
		ele2service = root.find('e2service')
		vpid = ele2service.find("e2vpid").text
		apid = ele2service.find("e2apid").text
		if vpid != "N/A":
			vpidI = int(vpid)
			capmt.extend([0x02, (vpidI >> 8) & 0xff, vpidI & 0xff, 0x00, 0x00])
			spidI = vpidI + 4 # subtitle PID is video PID plus four
			capmt.extend([0x06, (spidI >> 8) & 0xff, spidI & 0xff, 0x00, 0x00])
		if apid != "N/A":
			apidI = int(apid)
			capmt.extend([0x03, (apidI >> 8) & 0xff, apidI & 0xff, 0x00, 0x00])
	else:
		# descramble PMT PID
		capmt.extend([0x0d, (pmtPidI >> 8) & 0xff, pmtPidI & 0xff, 0x00, 0x00])

	# set length
	capmt[3] = len(capmt) - 4

	print ' '.join('0x%02x' % b for b in capmt)

	# send CAPMT to CAM
	s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
	s.connect_ex(("/tmp/camd.socket"))
	s.send(buffer(capmt))
	socketIsOpen = True

	if capmtType == "short":
		# get descrambled PMT now:
		print os.popen("""dvbsnoop -timeout 1000 -pd 1 -n 1 -demux %s %s | grep "received" """ % (demux,pmtPid)).readline().rstrip()

