#!/bin/sh

scriptPath=/usr/bin

#do cleanup
cd $scriptPath
killall -9 bbc_pmt_starter.sh
for scriptName in `ls -1 bbc_pmt*py`
do
	killall -9 $scriptName
done

export scriptPath
$scriptPath/bbc_pmt_starter.sh &

